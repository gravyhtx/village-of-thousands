"use strict";
(() => {
var exports = {};
exports.id = 221;
exports.ids = [221];
exports.modules = {

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 7619:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_dbConnect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2039);
/* harmony import */ var _models_Product__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(3417);
/* harmony import */ var _models_Product__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_models_Product__WEBPACK_IMPORTED_MODULE_1__);
 // import { signToken, authMiddleware } from "../../../utils/jwAuth";


(0,_utils_dbConnect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res) => {
  const {
    method
  } = req;

  switch (method) {
    case 'GET':
      try {
        const products = await _models_Product__WEBPACK_IMPORTED_MODULE_1___default().find({});
        res.status(200).json(products);
      } catch (err) {
        res.status(400).json({
          success: false,
          message: 'User Creation Error'
        });
      }

      break;

    case 'POST':
      try {
        const newProduct = await _models_Product__WEBPACK_IMPORTED_MODULE_1___default().create(req.body);
        res.status(201).json({
          newProduct,
          message: 'New Product added Successfully'
        });
      } catch (err) {
        res.status(400).json({
          success: false,
          message: 'User Creation Error'
        });
      }

      break;

    case 'PUT':
      try {
        res.status(200).json('updatedUser');
      } catch (err) {
        res.status(400).json({
          success: false,
          message: 'User Update Error'
        });
      }

      break;
  }
});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [893], () => (__webpack_exec__(7619)));
module.exports = __webpack_exports__;

})();