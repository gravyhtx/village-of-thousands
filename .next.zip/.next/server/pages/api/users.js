"use strict";
(() => {
var exports = {};
exports.id = 829;
exports.ids = [829];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 9384:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ users)
});

// EXTERNAL MODULE: ./utils/dbConnect.js
var dbConnect = __webpack_require__(2039);
// EXTERNAL MODULE: ./utils/jwAuth.js
var jwAuth = __webpack_require__(4492);
// EXTERNAL MODULE: ./models/User.js
var User = __webpack_require__(199);
var User_default = /*#__PURE__*/__webpack_require__.n(User);
// EXTERNAL MODULE: ./models/PendingUser.js
var PendingUser = __webpack_require__(4900);
var PendingUser_default = /*#__PURE__*/__webpack_require__.n(PendingUser);
;// CONCATENATED MODULE: external "@sendgrid/mail"
const mail_namespaceObject = require("@sendgrid/mail");
var mail_default = /*#__PURE__*/__webpack_require__.n(mail_namespaceObject);
;// CONCATENATED MODULE: ./utils/mailer.js
// const nodemailer = require('nodemailer');
// exports.sendConfirmationEmail = function({ toUser, hash }) {
//     return new Promise((res, rej) => {
//         const transporter = nodemailer.createTransport({
//             host: 'smtp.ethereal.email',
//             port: 587,
//             auth: {
//                 user: 'joyce.spencer72@ethereal.email',
//                 pass: '7RJkd1vTWMEQFce2B5'
//             }
//         });
//         const message = {
//             from: "joyce.spencer72@ethereal.email",
//             to: toUser.email,
//             subject: 'Welcome to the Vilage! Confirm your Account',
//             html: `
//             <h3> Suh Duhhhd ${toUser.email}</h3>
//             <p>Thank you for registering</p>
//             <p>Click here to activate your account <a target="_blank" href="${process.env.URL}/api/users/activate/${hash}">Link </a></p>
//             `
//             // SWITCH TO "/activate?id=${hash}" AND CHECK IF USER MATCHES ID?
//             // IF USER IS NOT LOGGED IN SEND ID TO LOGIN PAGE -- ONCED LOGGED IN CHECK WILL BE CONFIRMED (OR DENIED)
//         }
//         transporter.sendMail(message, function(err, info) {
//             if (err) {
//                 rej(err)
//             } else {
//                 res(info)
//             }
//         })
//     })
// }
// import emailjs from 'emailjs-com';
// exports.sendConfirmationEmail = function({ toUser, hash }) {
//     let templateParams = {
//         toUser: toUser.email,
//         hash: hash
//     }
//     return emailjs.send(
//         'service_zeibg8c',
//         'template_egwp7qf',
//         templateParams,
//         'user_89utuq-pdVRN8E-nZ'
//     )
// }

const sendConfirmationEmail = function ({
  toUser,
  hash
}) {
  // console.log('stuff')
  mail_default().setApiKey(process.env.SENDGRID); // console.log(process.env.SENDGRID)

  const msg = {
    to: toUser.email,
    from: "andreslong92@gmail.com",
    subject: 'Welcome to the Village!',
    test: 'some text for testing',
    html: `<h1> Village ${hash} </h1>`
  };
  return mail_default().send(msg);
};
;// CONCATENATED MODULE: ./pages/api/users/index.js





(0,dbConnect/* default */.Z)();
/* harmony default export */ const users = (async (req, res) => {
  const {
    method
  } = req;

  switch (method) {
    // case 'GET':
    //   try {
    //     const user = await User.find({});
    //     res.status(200).json(user);
    //   } catch (err) {
    //     res.status(400).json({ success: false, message: 'User Creation Error' });
    //   }
    //   break;
    case 'POST':
      try {
        const pUser = await PendingUser_default().findOne({
          email: req.body.email
        });
        const pUserCheck = await User_default().findOne({
          email: req.body.email
        });

        if (pUser || pUserCheck) {
          return res.status(422).json({
            success: false,
            message: "User email already exists"
          });
        }

        const user = await PendingUser_default().create(req.body); // const user = {
        //   email: req.body.email,
        //   _id: '12345678'
        // }

        console.log(user._id);
        const confirmation = await sendConfirmationEmail({
          toUser: user,
          hash: user._id.toString()
        }); // const confirmation = await sendConfirmationEmail()

        console.log(confirmation);
        const token = (0,jwAuth.signToken)(user);
        res.status(201).json({
          token,
          user,
          message: 'You have been registered! Please check your email for verification'
        });
      } catch (err) {
        res.status(400).json({
          success: false,
          message: 'User Creation Error',
          error: err
        });
      }

      break;

    case 'PUT':
      try {
        const authorization = await (0,jwAuth.authMiddleware)(req, res);

        if (!authorization) {
          return res.status(400).json({
            success: false,
            message: 'Unauthorized Token'
          });
        }

        const updatedUser = await User_default().findOneAndUpdate({
          _id: authorization._id
        }, req.body);
        res.status(200).json(updatedUser);
      } catch (err) {
        res.status(400).json({
          success: false,
          message: 'User Update Error'
        });
      }

      break;
  }
});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [684,492,900], () => (__webpack_exec__(9384)));
module.exports = __webpack_exports__;

})();