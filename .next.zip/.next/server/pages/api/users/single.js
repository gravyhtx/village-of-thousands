"use strict";
(() => {
var exports = {};
exports.id = 972;
exports.ids = [972];
exports.modules = {

/***/ 7096:
/***/ ((module) => {

module.exports = require("bcrypt");

/***/ }),

/***/ 9344:
/***/ ((module) => {

module.exports = require("jsonwebtoken");

/***/ }),

/***/ 1185:
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ 854:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _utils_dbConnect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2039);
/* harmony import */ var _utils_jwAuth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4492);
/* harmony import */ var _utils_jwAuth__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_utils_jwAuth__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(199);
/* harmony import */ var _models_User__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_models_User__WEBPACK_IMPORTED_MODULE_2__);



(0,_utils_dbConnect__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z)();
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (async (req, res) => {
  const {
    method
  } = req;

  switch (method) {
    case 'GET':
      try {
        const authorization = await (0,_utils_jwAuth__WEBPACK_IMPORTED_MODULE_1__.authMiddleware)(req, res);

        if (!authorization) {
          return res.status(400).json({
            success: false,
            message: 'Unauthorized Token'
          });
        }

        const foundUser = await _models_User__WEBPACK_IMPORTED_MODULE_2___default().findOne({
          $or: [{
            _id: authorization._id
          }, {
            email: authorization.email
          }]
        });

        if (!foundUser) {
          return res.status(400).json({
            message: 'Cannot find a user with this id!'
          });
        }

        res.status(200).json(foundUser);
      } catch (err) {
        res.status(400).json({
          success: false,
          message: 'User Tracking Error'
        });
      }

      break;
  }
});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [684,492], () => (__webpack_exec__(854)));
module.exports = __webpack_exports__;

})();