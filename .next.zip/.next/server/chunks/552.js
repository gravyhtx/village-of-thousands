"use strict";
exports.id = 552;
exports.ids = [552];
exports.modules = {

/***/ 3450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ AddressFormContainer)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/FormInputs.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const FormInputs = ({
  fields,
  setData,
  aria
}) => {
  const {
    0: formData,
    1: setFormData
  } = useState({});
  setData = formData;

  const handleChange = event => {
    const {
      name,
      value
    } = event.target;
    setFormData(_objectSpread(_objectSpread({}, formData), {}, {
      [name]: value
    }));
  };

  return /*#__PURE__*/_jsx(_Fragment, {
    children: fields.map((field, index) => {
      return /*#__PURE__*/_jsx("input", {
        className: "input-field",
        id: "user-register-" + field.name + "_input",
        "aria-labelledby": aria || '',
        name: field.placeholder,
        placeholder: field.placeholder,
        onChange: handleChange
      }, index);
    })
  });
};

/* harmony default export */ const components_FormInputs = ((/* unused pure expression or super */ null && (FormInputs)));
// EXTERNAL MODULE: ./utils/auth.js
var auth = __webpack_require__(7701);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./utils/API.js
var API = __webpack_require__(9512);
;// CONCATENATED MODULE: ./components/AddressFormContainer.js
function AddressFormContainer_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function AddressFormContainer_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { AddressFormContainer_ownKeys(Object(source), true).forEach(function (key) { AddressFormContainer_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { AddressFormContainer_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function AddressFormContainer_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











const AddressForm = () => {
  // Get User Data
  const {
    0: userData,
    1: setUserData
  } = (0,external_react_.useState)({});
  const userDataLength = Object.keys(userData).length;
  const {
    0: windowLocation,
    1: setWindowLocation
  } = (0,external_react_.useState)('');
  let router = (0,router_.useRouter)();
  (0,external_react_.useEffect)(() => {
    const getUserData = async () => {
      setWindowLocation(router.pathname);

      try {
        const token = auth/* default.loggedIn */.Z.loggedIn() ? auth/* default.getToken */.Z.getToken() : null;
        const response = await (0,API/* getSingleUser */.fp)(token); // console.log(token);

        if (!response.ok) {
          throw new Error('Something went wrong!');
        }

        const user = await response.json();
        setUserData(user);
      } catch (err) {
        console.error(err);
      }
    };

    getUserData();
  }, [userDataLength]);
  const {
    0: userFormData,
    1: setUserFormData
  } = (0,external_react_.useState)({});

  const handleInputChange = event => {
    const {
      name,
      value
    } = event.target;
    setUserFormData(AddressFormContainer_objectSpread(AddressFormContainer_objectSpread({}, userFormData), {}, {
      [name]: value
    }));
  };

  const handleFormSubmit = async event => {
    event.preventDefault();
    const form = event.currentTarget;

    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    const token = auth/* default.loggedIn */.Z.loggedIn() ? auth/* default.getToken */.Z.getToken() : null;

    if (!token) {
      router.push('/404');
      return false;
    }

    try {
      const response = await (0,API/* updateUser */.Nq)(userFormData, token);

      if (!response.ok) {
        throw new Error('something went wrong!');
      }
    } catch (err) {
      console.error(err);
    }

    setUserFormData({
      first_name: "",
      last_name: "",
      // OPTIONAL //
      phone: "",
      // ENTER IN ADDRESS FORM //
      addressOne: "",
      addressTwo: "",
      city: "",
      state: "",
      zip: "" // // GET FROM NEW WALLET APP //
      // walletAddress: "",
      // walletBalance: "",
      // completed: true

    });
    localStorage.removeItem('seed_hex');
    router.push('/');
  };

  const fields = [{
    name: 'addressOne',
    placeholder: 'Address Line 1'
  }, {
    name: 'addressTwo',
    placeholder: 'Address Line 2'
  }, {
    name: 'city',
    placeholder: 'City'
  }, {
    name: 'state',
    placeholder: 'State'
  }, {
    name: 'zip',
    placeholder: 'Zip'
  }];

  const userAddress = field => {
    return userData.field;
  };

  console.log(userAddress(fields[0]));
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "register-address-container container",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "register-input-container",
        id: "user-register-container",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "user-register-address-header",
          children: "ADDRESS"
        }), fields.map((field, index) => {
          return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
            children: /*#__PURE__*/jsx_runtime_.jsx("input", {
              className: "input-field",
              id: "user-register-" + field.name + "_input",
              "aria-labelledby": "user-register-address",
              name: field.name,
              placeholder: field.placeholder // placeholder={userData.addressOne?userData.addressOne:'Address Line 1'}
              ,
              onChange: handleInputChange // value={userData.addressOne?userData.addressOne:''}

            }, index)
          });
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("br", {}), windowLocation === "/signup-2" ? /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "user-register-finish",
        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "account-wallet-btn",
          onClick: handleFormSubmit,
          children: "COMPLETE REGISTRATION"
        })
      }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "user-address-edit",
        children: /*#__PURE__*/jsx_runtime_.jsx("button", {
          className: "account-wallet-btn",
          onClick: handleFormSubmit,
          children: "EDIT ADDRESS"
        })
      })]
    })
  });
};

/* harmony default export */ const AddressFormContainer = (AddressForm);

/***/ }),

/***/ 9786:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Web3Wallet)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "@web3-react/core"
var core_ = __webpack_require__(8054);
// EXTERNAL MODULE: external "@ethersproject/providers"
var providers_ = __webpack_require__(399);
// EXTERNAL MODULE: external "@web3-react/injected-connector"
var injected_connector_ = __webpack_require__(6590);
// EXTERNAL MODULE: external "@ethersproject/units"
var units_ = __webpack_require__(3138);
;// CONCATENATED MODULE: ./utils/hooks.ts



const injected = new injected_connector_.InjectedConnector({
  supportedChainIds: [1, 3, 4, 5, 42]
});
function useEagerConnect() {
  const {
    activate,
    active
  } = (0,core_.useWeb3React)();
  const {
    0: tried,
    1: setTried
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    injected.isAuthorized().then(isAuthorized => {
      if (isAuthorized) {
        activate(injected, undefined, true).catch(() => {
          setTried(true);
        });
      } else {
        setTried(true);
      }
    });
  }, [activate]); // intentionally only running on mount (make sure it's only mounted once :))
  // if the connection worked, wait until we get confirmation of that to flip the flag

  (0,external_react_.useEffect)(() => {
    if (!tried && active) {
      setTried(true);
    }
  }, [tried, active]);
  return tried;
}
function useInactiveListener(suppress = false) {
  const {
    active,
    error,
    activate
  } = (0,core_.useWeb3React)();
  (0,external_react_.useEffect)(() => {
    const {
      ethereum
    } = window;

    if (ethereum && ethereum.on && !active && !error && !suppress) {
      const handleConnect = () => {
        console.log("Handling 'connect' event");
        activate(injected);
      };

      const handleChainChanged = chainId => {
        console.log("Handling 'chainChanged' event with payload", chainId);
        activate(injected);
      };

      const handleAccountsChanged = accounts => {
        console.log("Handling 'accountsChanged' event with payload", accounts);

        if (accounts.length > 0) {
          activate(injected);
        }
      };

      const handleNetworkChanged = networkId => {
        console.log("Handling 'networkChanged' event with payload", networkId);
        activate(injected);
      };

      ethereum.on('connect', handleConnect);
      ethereum.on('chainChanged', handleChainChanged);
      ethereum.on('accountsChanged', handleAccountsChanged);
      ethereum.on('networkChanged', handleNetworkChanged);
      return () => {
        if (ethereum.removeListener) {
          ethereum.removeListener('connect', handleConnect);
          ethereum.removeListener('chainChanged', handleChainChanged);
          ethereum.removeListener('accountsChanged', handleAccountsChanged);
          ethereum.removeListener('networkChanged', handleNetworkChanged);
        }
      };
    }
  }, [active, error, suppress, activate]);
}
// EXTERNAL MODULE: ./utils/API.js
var API = __webpack_require__(9512);
// EXTERNAL MODULE: ./utils/auth.js
var auth = __webpack_require__(7701);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Web3Connect.tsx












const Web3Connect_injected = new injected_connector_.InjectedConnector({
  supportedChainIds: [1, 3, 4, 5, 42]
});

function getErrorMessage(error) {
  if (error instanceof injected_connector_.NoEthereumProviderError) {
    return 'No Ethereum browser extension detected, install MetaMask on desktop or visit from a dApp browser on mobile.';
  } else if (error instanceof core_.UnsupportedChainIdError) {
    return "You're connected to an unsupported network.";
  } else if (error instanceof injected_connector_.UserRejectedRequestError) {
    return 'Please authorize this website to access your Ethereum account.';
  } else {
    console.error(error);
    return 'An unknown error occurred. Check the console for more details.';
  }
}

function getLibrary(provider) {
  const library = new providers_.Web3Provider(provider);
  library.pollingInterval = 12000;
  return library;
}

function ChainId() {
  const {
    chainId
  } = useWeb3React();
  const userChainId = chainId !== null && chainId !== void 0 ? chainId : '';
  console.log("Chain ID: " + userChainId);
}

function BlockNumber() {
  const {
    chainId,
    library
  } = useWeb3React();
  const [blockNumber, setBlockNumber] = React.useState();
  React.useEffect(() => {
    if (!!library) {
      let stale = false;
      library.getBlockNumber().then(blockNumber => {
        if (!stale) {
          setBlockNumber(blockNumber);
        }
      }).catch(() => {
        if (!stale) {
          setBlockNumber(null);
        }
      });

      const updateBlockNumber = blockNumber => {
        setBlockNumber(blockNumber);
      };

      library.on('block', updateBlockNumber);
      return () => {
        stale = true;
        library.removeListener('block', updateBlockNumber);
        setBlockNumber(undefined);
      };
    }
  }, [library, chainId]); // ensures refresh if referential identity of library doesn't change across chainIds

  const userBlocknumber = blockNumber === null ? 'Error' : blockNumber !== null && blockNumber !== void 0 ? blockNumber : '';
  console.log("Block Number: " + userBlocknumber);
}

function Account() {
  const {
    account
  } = (0,core_.useWeb3React)();
  const userAccount = account === null ? '-' : account ? account : ''; // console.log(userAccount)

  const token = auth/* default.loggedIn */.Z.loggedIn() ? auth/* default.getToken */.Z.getToken() : null; // if (!token) {
  //     // window.location.assign('/404');
  //     return false;
  // }

  try {
    let updateObj = {
      walletAddress: userAccount
    };
    (0,API/* updateUser */.Nq)(updateObj, token).then(response => {
      if (!response.ok) {
        throw new Error('something went wrong!');
      }
    }); // const response = await updateUser(updateObj, token);
    // if(!response.ok) {
    //   throw new Error('something went wrong!');
    // }
  } catch (err) {
    console.error(err);
  }

  return userAccount;
}

function Balance() {
  const {
    account,
    library,
    chainId
  } = useWeb3React();
  const [balance, setBalance] = React.useState();
  React.useEffect(() => {
    if (!!account && !!library) {
      let stale = false;
      library.getBalance(account).then(balance => {
        if (!stale) {
          setBalance(balance);
        }
      }).catch(() => {
        if (!stale) {
          setBalance(null);
        }
      });
      return () => {
        stale = true;
        setBalance(undefined);
      };
    }
  }, [account, library, chainId]); // ensures refresh if referential identity of library doesn't change across chainIds

  const userBalance = balance === null ? 'Error' : balance ? formatEther(balance) : '';
  console.log(userBalance + " ETH");
}

/* harmony default export */ function Web3Connect() {
  return /*#__PURE__*/jsx_runtime_.jsx(core_.Web3ReactProvider, {
    getLibrary: getLibrary,
    children: /*#__PURE__*/jsx_runtime_.jsx(App, {})
  });
} // const AddWallet = (walletAddress, walletBalance) => {
//   // Get User Data
//   const [userData, setUserData] = useState({});
//   const userDataLength = Object.keys(userData).length;
//   useEffect(() => {
//   const getUserData = async () => {
//       try {
//           const token = Auth.loggedIn() ? Auth.getToken() : null;
//           const response = await getSingleUser(token);
//           if(!response.ok){
//               throw new Error('something went wrong!');
//           }
//           const user = await response.json();
//           setUserData(user);
//       } catch (err) {
//           console.error(err);
//       }
//   };
//   getUserData();
//   // console.log(userData);
//   }, [userDataLength]);
//   const [userWallet, setUserWallet] = useState({walletAddress:'', walletBalance:''})
//   const submitWallet = async (event) => {
//       event.preventDefault();
//       const form = event.currentTarget;
//       if(form.checkValidity() === false) {
//           event.preventDefault();
//           event.stopPropagation();
//       }
//       const token = Auth.loggedIn() ? Auth.getToken() : null;
//       if (!token) {
//           window.location.assign('/404');
//           return false;
//       }
//       try {
//           const response = await updateUser(userWallet, token);
//           if(!response.ok) {
//               throw new Error('something went wrong!');
//           }
//       } catch (err) {
//           console.error(err);
//       }
//       setUserWallet({
//           walletAddress: walletAddress,
//           walletBalance: walletBalance
//       })
//       window.location.assign('/');
//   }
// }
// ChainId();
// BlockNumber();
// Balance();

function Header() {
  // const { active, error } = useWeb3React()
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "wallet-info",
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: Account()
    })
  });
}

function App() {
  const context = (0,core_.useWeb3React)();
  const {
    connector,
    library,
    account,
    activate,
    deactivate,
    active,
    error
  } = context; // handle logic to recognize the connector currently being activated

  const [activatingConnector, setActivatingConnector] = external_react_default().useState();
  external_react_default().useEffect(() => {
    if (activatingConnector && activatingConnector === connector) {
      setActivatingConnector(undefined);
    }
  }, [activatingConnector, connector]); // handle logic to eagerly connect to the injected ethereum provider, if it exists and has granted access already

  const triedEager = useEagerConnect(); // handle logic to connect in reaction to certain events on the injected ethereum provider, if it exists

  useInactiveListener(!triedEager || !!activatingConnector);
  const currentConnector = Web3Connect_injected;
  const activating = currentConnector === activatingConnector;
  const connected = currentConnector === connector;
  const disabled = !triedEager || !!activatingConnector || connected || !!error; // Get User Data

  const {
    0: userData,
    1: setUserData
  } = (0,external_react_.useState)({});
  const userDataLength = Object.keys(userData).length;
  (0,external_react_.useEffect)(() => {
    const getUserData = async () => {
      try {
        const token = auth/* default.loggedIn */.Z.loggedIn() ? auth/* default.getToken */.Z.getToken() : null;
        const response = await (0,API/* getSingleUser */.fp)(token);

        if (!response.ok) {
          throw new Error('something went wrong!');
        }

        const user = await response.json();
        setUserData(user);
      } catch (err) {
        console.error(err);
      }
    };

    getUserData(); // console.log(userData);
  }, [userDataLength]);
  const {
    0: userWallet,
    1: setUserWallet
  } = (0,external_react_.useState)({
    walletAddress: "",
    walletBalance: ""
  });

  const submitWallet = async () => {// event.preventDefault();
    // const wallAddress = Account()
    // // const form = event.currentTarget;
    // // if(form.checkValidity() === false) {
    // //     event.preventDefault();
    // //     event.stopPropagation();
    // // }
    // console.log(wallAddress)
    // setUserWallet({
    //     walletAddress: getAddress,
    //     walletBalance: getBalance
    // })
    // window.location.assign('/');
  };

  const web3activate = async () => {
    setActivatingConnector(currentConnector);
    const activeWallet = await activate(Web3Connect_injected);
    submitWallet(); // submitWallet()
    // if (window.location.pathname === '/account') {
    //   window.location.reload()
    // }
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Header, {}), !active && /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        className: "btn waves-effect waves-light account-wallet-btn",
        disabled: disabled,
        onClick: () => {
          web3activate();
        },
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          children: connected
        }), "ADD WALLET"]
      })
    }), (active || error) && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "btn waves-effect waves-light account-wallet-btn",
        onClick: () => {
          deactivate();
        },
        children: "DEACTIVATE WALLET"
      }), !!error && /*#__PURE__*/jsx_runtime_.jsx("h4", {
        style: {
          marginTop: '1rem',
          marginBottom: '0'
        },
        children: getErrorMessage(error)
      })]
    })]
  });
}
;// CONCATENATED MODULE: ./components/Web3Wallet.tsx






function Web3Wallet_getLibrary(provider) {
  const library = new providers_.Web3Provider(provider);
  library.pollingInterval = 12000;
  return library;
}

const Web3Wallet = () => {
  return /*#__PURE__*/jsx_runtime_.jsx(core_.Web3ReactProvider, {
    getLibrary: Web3Wallet_getLibrary,
    children: /*#__PURE__*/jsx_runtime_.jsx(Web3Connect, {})
  });
};

/* harmony default export */ const components_Web3Wallet = (Web3Wallet);

/***/ })

};
;