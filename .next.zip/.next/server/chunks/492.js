exports.id = 492;
exports.ids = [492];
exports.modules = {

/***/ 4492:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const jwt = __webpack_require__(9344); // set token secret and expiration date


const secret = 'mysecretsshhhhh';
const expiration = '2h';
module.exports = {
  // function for our authenticated routes
  authMiddleware: function (req, res, next) {
    // allows token to be sent via  req.query or headers
    let token = req.query.token || req.headers.authorization; // ["Bearer", "<tokenvalue>"]

    if (req.headers.authorization) {
      token = token.split(' ').pop().trim();
    }

    if (!token) {
      return res.status(400).json({
        message: 'You have no token!'
      });
    } // verify token and get user data out of it


    try {
      const {
        data
      } = jwt.verify(token, secret, {
        maxAge: expiration
      }); // console.log(data)

      return data;
    } catch {
      console.log('Invalid token');
      return res.status(400).json({
        message: 'invalid token!'
      });
    } // send to next endpoint
    // next();

  },
  signToken: function ({
    email,
    _id
  }) {
    const payload = {
      email,
      _id
    };
    return jwt.sign({
      data: payload
    }, secret, {
      expiresIn: expiration
    });
  }
};

/***/ })

};
;