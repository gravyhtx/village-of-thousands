exports.id = 893;
exports.ids = [893];
exports.modules = {

/***/ 3417:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mongoose = __webpack_require__(1185);

const {
  Schema,
  model
} = mongoose;
mongoose.Promise = global.Promise;
const productSchema = new Schema({
  product_name: {
    type: String,
    required: true,
    unique: true
  },
  product_path: {
    type: String,
    required: true
  },
  product_image: [{
    type: String,
    required: false
  }],
  product_description: [{
    type: String,
    required: false
  }],
  product_colors: [{
    type: String
  }],
  product_genders: [{
    type: String
  }],
  product_sizes: [{
    type: String
  }],
  SKU: {
    type: String,
    required: false
  },
  inventory: [{
    type: Number,
    required: false,
    min: 0
  }],
  price: {
    type: Number,
    required: false,
    min: 0.99
  },
  NFT_include: {
    type: Boolean
  }
}, {
  toJSON: {
    virtuals: true
  }
}); // const Product = model('Product', productSchema);

module.exports = mongoose.models.Product || model('Product', productSchema);

/***/ }),

/***/ 2039:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connection = {};

async function dbConnect() {
  if (connection.isConnected) {
    return;
  }

  const db = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI);
  connection.isConnected = db.connections[0].readyState; // console.log(connection)
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);

/***/ })

};
;