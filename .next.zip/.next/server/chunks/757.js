"use strict";
exports.id = 757;
exports.ids = [757];
exports.modules = {

/***/ 4757:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_LoginContainer)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
// EXTERNAL MODULE: external "@mui/material/AccordionSummary"
var AccordionSummary_ = __webpack_require__(4604);
var AccordionSummary_default = /*#__PURE__*/__webpack_require__.n(AccordionSummary_);
// EXTERNAL MODULE: ./templates/DefaultLayout.js + 9 modules
var DefaultLayout = __webpack_require__(388);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./utils/API.js
var API = __webpack_require__(9512);
// EXTERNAL MODULE: ./utils/auth.js
var auth = __webpack_require__(7701);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/Login.js
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }











const Login = () => {
  const router = (0,router_.useRouter)();
  const {
    0: userFormData,
    1: setUserFormData
  } = (0,external_react_.useState)({
    email: '',
    password: ''
  });

  const handleInputChange = event => {
    const {
      name,
      value
    } = event.target;
    setUserFormData(_objectSpread(_objectSpread({}, userFormData), {}, {
      [name]: value
    }));
  };

  const handleFormSubmit = async event => {
    event.preventDefault();
    const form = event.currentTarget;

    if (form.checkValidity() === false) {
      event.preventDefault();
      event.stopPropagation();
    }

    try {
      const response = await (0,API/* loginUser */.pH)(userFormData);

      if (!response.ok) {
        throw new Error('something went wrong!');
      }

      const {
        token,
        user
      } = await response.json(); // console.log(user);

      auth/* default.login */.Z.login(token);
      router.push('/');
    } catch (err) {
      console.error(err);
    }

    setUserFormData({
      email: '',
      password: ''
    });
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "login-input-container",
      id: "user-login-container",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "login-input-label",
        id: "user-login-email",
        children: "Email"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "input-field col",
        children: /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "email",
          className: "input-field",
          id: "user-login-email_input",
          "aria-labelledby": "user-login-email",
          name: "email",
          onChange: handleInputChange,
          value: userFormData.email
        })
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "login-input-container",
      id: "user-login-container",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "login-input-label",
        id: "user-login-password",
        children: ["Password\xA0", /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
          href: "/recover-password",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
              className: "forgot-password",
              children: ["// ", /*#__PURE__*/jsx_runtime_.jsx("u", {
                className: "forgot-password-link",
                children: "Forgot password?"
              })]
            })
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "input-field col",
        children: /*#__PURE__*/jsx_runtime_.jsx("input", {
          type: "password",
          className: "input-field",
          id: "user-login-password_input",
          "aria-labelledby": "user-login-password",
          autoComplete: "current-password",
          name: "password",
          onChange: handleInputChange,
          value: userFormData.password
        })
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "center-text",
      children: /*#__PURE__*/jsx_runtime_.jsx("button", {
        onClick: handleFormSubmit,
        className: "login-btn",
        children: "SIGN IN"
      })
    })]
  });
};

/* harmony default export */ const components_Login = (Login);
;// CONCATENATED MODULE: ./components/Register.js
function Register_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function Register_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { Register_ownKeys(Object(source), true).forEach(function (key) { Register_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { Register_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function Register_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }










const Register = () => {
  const {
    0: userFormData,
    1: setUserFormData
  } = (0,external_react_.useState)({
    email: '',
    password: '',
    mnemonic: ''
  });
  const {
    0: formError,
    1: setFormError
  } = (0,external_react_.useState)({
    email: '',
    password: '',
    passwordSpacing: ''
  });
  const {
    0: errorClass,
    1: setErrorClass
  } = (0,external_react_.useState)({
    email: '',
    password: ''
  });
  const {
    0: pass,
    1: setPass
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    handleFormSubmit();
  }, [pass]);
  const router = (0,router_.useRouter)();
  const errorElements = [/*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "signup-error error-message italics",
    id: "email-error",
    children: "Please enter a valid email address."
  }), /*#__PURE__*/jsx_runtime_.jsx("span", {
    className: "signup-error error-message italics",
    id: "password-error",
    children: "Password must be between 6 to 20 characters withat least one numeric digit, one uppercase, and one lowercase letter."
  }), /*#__PURE__*/jsx_runtime_.jsx("span", {
    className: "signup-error error-message italics",
    id: "password-error",
    children: "Password cannot contain spaces."
  })];

  const handleInputChange = event => {
    const {
      name,
      value
    } = event.target;
    setUserFormData(Register_objectSpread(Register_objectSpread({}, userFormData), {}, {
      [name]: value
    }));
    setErrorClass({
      email: '',
      password: '',
      passwordSpacing: ''
    });
  };

  function formValidation(email, password) {
    var emailFormat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    const pwFormat = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,20}$/; // 6 to 20 characters with at least one numeric digit, one uppercase and one lowercase letter

    const pwFormatSpaces = /^\S*$/; // No white space

    if (emailFormat.test(email) && pwFormat.test(password) && pwFormatSpaces.test(password)) {
      setPass(true); // console.log('passing statements have been activated')
    } else {
      // console.log('failing statements have been activated')
      setPass(false);
    }

    setFormError({
      email: email.match(emailFormat) ? '' : errorElements[0],
      password: password.match(pwFormat) ? '' : errorElements[1],
      passwordSpacing: password.match(pwFormatSpaces) ? '' : errorElements[2]
    });
    setErrorClass({
      email: email.match(emailFormat) ? '' : ' input-error',
      password: password.match(pwFormat) && password.match(pwFormatSpaces) ? '' : ' input-error'
    });
  }

  const formHandlerPass = () => {
    formValidation(userFormData.email, userFormData.password, userFormData.passwordSpacing);
  };

  const handleFormSubmit = async () => {
    // event.preventDefault();
    // event.stopPropagation();
    if (!pass) {
      return;
    } // if(formError.email === errorElements[0] || formError.password === errorElements[1]) {


    try {
      const response = await (0,API/* createUser */.r4)(userFormData);

      if (!response.ok) {
        throw new Error('something went wrong!');
      }

      const {
        token,
        user
      } = await response.json(); // console.log(user.length);

      console.log(pass);

      if (pass) {
        auth/* default.login */.Z.login(token);
        localStorage.removeItem('seed_hex');
        router.push('/signup-1');
      }
    } catch (err) {
      console.error(err);
    }

    setUserFormData({
      email: '',
      password: '',
      mnemonic: 'false'
    });
  };

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "login-input-container",
      id: "user-register-container",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "login-input-label",
        id: "user-register-email",
        children: "Email"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "input-field col",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          name: "email",
          "aria-labelledby": "user-register-email",
          className: "input-field" + errorClass.email,
          id: "user-register-email_input",
          onChange: handleInputChange,
          value: userFormData.email
        }), formError.email]
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "login-input-container",
      id: "user-register-container",
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "login-input-label",
        id: "user-register-password",
        children: "Password"
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "input-field col",
        children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
          name: "password",
          type: "password",
          "aria-labelledby": "user-register-password",
          className: "input-field" + errorClass.password,
          id: "user-register-password_input",
          onChange: handleInputChange,
          value: userFormData.password
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          children: [formError.password, formError.password && formError.passwordSpacing ? /*#__PURE__*/jsx_runtime_.jsx("span", {
            children: "\xA0"
          }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {}), formError.passwordSpacing]
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "center-text",
      children: /*#__PURE__*/jsx_runtime_.jsx("button", {
        className: "login-btn",
        onClick: formHandlerPass,
        children: "Create Account"
      })
    })]
  });
};

/* harmony default export */ const components_Register = (Register);
// EXTERNAL MODULE: ./components/dynamic-content/RandomQuote.js
var RandomQuote = __webpack_require__(2919);
;// CONCATENATED MODULE: ./components/LoginContainer.js











const LoginContainer = ({
  name,
  message
}) => {
  const {
    0: expanded,
    1: setExpanded
  } = (0,external_react_.useState)(name || 'login');

  const handleChange = panel => (event, newExpanded) => {
    setExpanded(newExpanded ? panel : false);
  };

  const signupContainers = [{
    name: 'login',
    component: /*#__PURE__*/jsx_runtime_.jsx(components_Login, {})
  }, {
    name: 'register',
    component: /*#__PURE__*/jsx_runtime_.jsx(components_Register, {})
  }];

  const ErrorMessage = () => {
    return message ? /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "login-error",
      children: message
    }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {});
  };

  return /*#__PURE__*/jsx_runtime_.jsx(DefaultLayout/* default */.Z, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "row container signup-container animate__animated animate__fadeIn login-container",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "signup-collapsible",
        children: [/*#__PURE__*/jsx_runtime_.jsx(ErrorMessage, {}), signupContainers.map((container, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(material_.Accordion, {
          className: "collapsible",
          onChange: handleChange(container.name),
          expanded: expanded === container.name,
          disableGutters: true,
          children: [/*#__PURE__*/jsx_runtime_.jsx((AccordionSummary_default()), {
            className: "collapsible-header center",
            id: "login-header",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "login-header disable-highlight",
              children: (0,material_.capitalize)(container.name)
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(material_.AccordionDetails, {
            className: container.name + "-collapsible-item",
            children: container.component
          })]
        }, index))]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "center-text italics",
        children: /*#__PURE__*/jsx_runtime_.jsx(RandomQuote/* default */.Z, {
          className: "center-text login-zen",
          type: "zen"
        })
      })]
    })
  });
};

/* harmony default export */ const components_LoginContainer = (LoginContainer);

/***/ })

};
;