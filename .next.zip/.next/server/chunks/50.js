"use strict";
exports.id = 50;
exports.ids = [50];
exports.modules = {

/***/ 4050:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);



// ART //
// import Bro from "../public/images/art/bro.png";
// import Cartas from "../public/images/art/cartas.png";
// import ChooseYourVoT from "../public/images/art/choose_your_vot.png";
// import CopError from "../public/images/art/cop_error.png";
// import FallError from "../public/images/art/fall_error.png";
// import Hope from "../public/images/art/hope.png";
// import Riko from "../public/images/art/riko.png";
// import SpecialOrder from "../public/images/art/special_order.png";
const SiteImage = ({
  images,
  width,
  containerClasses,
  imgClasses,
  description
}) => {
  let cClass = "";

  if (containerClasses) {
    cClass = " " + containerClasses;
  }

  ;
  let iClass = "";

  if (imgClasses) {
    iClass = " " + imgClasses;
  }

  ;
  let imgSize = {};

  if (width) {
    imgSize = {
      maxWidth: width
    };
  }

  ;
  const n = images ? Math.floor(Math.random() * images.length) : 0;
  const image = Array.isArray(images) ? images[n] : images;
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
    children: images ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: "image-container" + cClass,
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
        style: imgSize,
        className: "image-class" + iClass,
        alt: description,
        src: image.src
      })
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {})
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SiteImage);

/***/ })

};
;