"use strict";
exports.id = 388;
exports.ids = [388];
exports.modules = {

/***/ 1677:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5675);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const ImageContainer = ({
  width,
  containerClasses,
  imgClasses,
  layout,
  description,
  src,
  id,
  svg,
  priority,
  blur,
  drag,
  contain
}) => {
  containerClasses = containerClasses ? ' ' + containerClasses : '';
  imgClasses = imgClasses ? ' ' + imgClasses : '';
  width = width ? {
    maxWidth: width
  } : '';
  layout = layout ? layout : 'responsive';
  id = id ? id : '';
  priority = priority ? priority : '';
  svg = svg ? svg : false;
  blur = blur ? "blur" : "";
  drag = drag ? drag : false;
  contain = contain ? " contain" : "";
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
    className: "image-container" + containerClasses + contain,
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__["default"], {
      layout: layout,
      className: "image-class" + imgClasses,
      alt: description,
      src: src,
      id: id,
      placeholder: blur,
      draggable: drag,
      priority: priority
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ImageContainer);

/***/ }),

/***/ 2874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1664);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const SvgContainer = ({
  margins,
  src,
  link,
  color,
  width,
  description,
  container,
  classes,
  id,
  styles,
  drag,
  maxWidth
}) => {
  let svgContainer = "";

  if (container) {
    svgContainer = " " + container;
  }

  let svgClass = "";

  if (classes) {
    svgClass = " " + classes;
  }

  let svgId = "";

  if (id) {
    svgId = " " + id;
  }

  if (color === "white") {
    color = "invert(100%)";
  }

  margins = margins ? margins : "0 auto";
  let svgStyles = {
    margin: margins,
    // width:width,
    maxWidth: maxWidth,
    styles
  };
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(next_link__WEBPACK_IMPORTED_MODULE_0__["default"], {
    href: link ? link : '/',
    target: "_blank",
    rel: "noreferrer",
    children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("a", {
      target: "_blank",
      rel: "noreferrer",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
        className: "svg-container" + svgContainer,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("img", {
          style: svgStyles ? svgStyles : {},
          src: src ? src.src : "" // width={width}
          ,
          className: "svg-img" + svgClass,
          id: svgId ? "svg-img_" + svgId : "",
          draggable: drag ? drag : false,
          alt: description
        })
      })
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SvgContainer);

/***/ }),

/***/ 3998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "iP": () => (/* binding */ useWindowSize)
/* harmony export */ });
/* unused harmony exports screenWidth, screenHeight, isMobileBreak */
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useWindowSize() {
  // Initialize state with undefined width/height so server and client renders match
  // Learn more here: https://joshwcomeau.com/react/the-perils-of-rehydration/
  const {
    0: windowSize,
    1: setWindowSize
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
    width: undefined,
    height: undefined
  });
  (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(() => {
    // Handler to call on window resize
    function handleResize() {
      // Set window width/height to state
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight
      });
    } // Add event listener


    window.addEventListener("resize", handleResize); // Call handler right away so state gets updated with initial window size

    handleResize(); // Remove event listener on cleanup

    return () => window.removeEventListener("resize", handleResize);
  }, []); // Empty array ensures that effect is only run on mount

  return windowSize;
}
const screenWidth = () => {
  return useWindowSize().width;
};
const screenHeight = () => {
  return useWindowSize().height;
};
const isMobileBreak = () => {
  return 'fun';
};

/***/ }),

/***/ 388:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ DefaultLayout)
});

// EXTERNAL MODULE: ./modules/getWindow.js
var getWindow = __webpack_require__(3998);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./utils/auth.js
var auth = __webpack_require__(7701);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/context/UserDataContext.js




const UserDataContext = /*#__PURE__*/(0,external_react_.createContext)();
const UpdateUserData = /*#__PURE__*/(/* unused pure expression or super */ null && (createContext()));
function useUserDataContext() {
  return useContext(UserDataContext);
}
const UserDataProvider = props => {
  const {
    0: userData,
    1: setUserData
  } = (0,external_react_.useState)({
    email: 'test@test.com',
    password: '',
    seedHex: '',
    first_name: '',
    last_name: '',
    phone: '',
    addressOne: '',
    addressTwo: '',
    city: '',
    state: '',
    zip: '',
    walletAddress: '',
    walletBalance: null,
    completeRegistration: undefined,
    blockie: '',
    colorScheme: []
  }); // the value that will be given to the context

  const {
    0: user,
    1: setUser
  } = (0,external_react_.useState)(null); // fetch a user from a fake backend API

  (0,external_react_.useEffect)(() => {
    const fetchUser = () => {
      // this would usually be your own backend, or localStorage
      // for example
      fetch('https://randomuser.me/api/').then(response => response.json()).then(result => setUser(result.results[0])).catch(error => console.log('An error occurred'));
    };

    fetchUser(); // console.log(user)
  }, []); // const providerValue = useMemo(() => {(userData, setUserData)}, [userData, setUserData]);

  (0,external_react_.useEffect)(() => {// Auth.loggedIn ? console.log('logged in') : console.log('not logged in');
    // console.log(userData);
  });
  return /*#__PURE__*/jsx_runtime_.jsx(UserDataContext.Provider, {
    value: user,
    children: props.children
  });
};
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "@mui/material"
var material_ = __webpack_require__(5692);
;// CONCATENATED MODULE: ./components/TopNav.js





const TopNav = () => {
  const account = auth/* default.loggedIn */.Z.loggedIn() ? "/account" : "/login";
  const navlinks = [{
    name: "account",
    ref: "person",
    link: account
  }, {
    name: "products",
    ref: "remove_red_eye",
    link: "/shop"
  }, {
    name: "faq",
    ref: "all_inclusive",
    link: "/faq"
  }, {
    name: "cart",
    ref: "shopping_cart",
    link: "/cart"
  }];
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "top-nav disable-highlight row",
    children: navlinks.map((item, index) => /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "col s3 nav-top-col",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: item.link,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: /*#__PURE__*/jsx_runtime_.jsx("button", {
            color: "inherit",
            className: "btn-floating btn-floating navigation-link nav-" + item.name,
            children: /*#__PURE__*/jsx_runtime_.jsx(material_.Icon, {
              className: "material-Icons nav-icon",
              children: item.ref
            })
          })
        })
      })
    }, index))
  });
};

/* harmony default export */ const components_TopNav = (TopNav);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: ./components/SvgContainer.js
var SvgContainer = __webpack_require__(2874);
;// CONCATENATED MODULE: ./components/NotificationBar.js





const NotificationBar = ({
  text,
  link
}) => {
  const component = /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
    href: link,
    className: "nav-link",
    id: "notify-link",
    children: /*#__PURE__*/jsx_runtime_.jsx("a", {
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "notify",
        id: "notify",
        children: text
      })
    })
  });

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: text ? component : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {})
  });
};

/* harmony default export */ const components_NotificationBar = (NotificationBar);
// EXTERNAL MODULE: ./config/site-data.json
var site_data = __webpack_require__(2315);
// EXTERNAL MODULE: ./utils/API.js
var API = __webpack_require__(9512);
;// CONCATENATED MODULE: ./public/images/header.png
/* harmony default export */ const header = ({"src":"/_next/static/media/header.19a42fb4.png","height":79,"width":1080,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAABCAYAAADjAO9DAAAAIElEQVR4nGP89+/fJAYGBg4gZgPiJ0DMC8TCQMwKxEwAfusEp7Y2FNQAAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./public/images/header.svg
/* harmony default export */ const images_header = ({"src":"/_next/static/media/header.62a5cb37.svg","height":80,"width":1100});
// EXTERNAL MODULE: ./components/ImageContainer.js
var ImageContainer = __webpack_require__(1677);
;// CONCATENATED MODULE: ./components/Header.js
 // import { Link, useLocation } from "react-router-dom";


 // import Logo from "../images/header.svg";
// import Image from 'next/image';
// import ImageContainer from "./ImageContainer";














const Header = () => {
  // Get User Data
  const {
    0: userData,
    1: setUserData
  } = (0,external_react_.useState)({});
  const userDataLength = Object.keys(userData).length;
  (0,external_react_.useEffect)(() => {
    const getUserData = async () => {
      try {
        const token = auth/* default.loggedIn */.Z.loggedIn() ? auth/* default.getToken */.Z.getToken() : null;
        const response = await (0,API/* getSingleUser */.fp)(token);

        if (!response.ok) {
          throw new Error('something went wrong!');
        }

        const user = await response.json();
        setUserData(user);
      } catch (err) {
        console.error(err);
      }
    }; // console.log(userData)


    getUserData();
  }, [userDataLength]); // const getWallet = localStorage.getItem('-walletlink:https://www.walletlink.org:Addresses');

  let siteName = site_data/* name */.u2;
  let notification; // const { asPath, pathname } = withRouter();
  // console.log(asPath); // '/blog/xyz'
  // console.log(pathname); // '/blog/[slug]'

  const router = (0,router_.useRouter)();
  const path = router.pathname;
  const notificationLink = "/register";
  notification = /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: ["Create your account today and get a ", /*#__PURE__*/jsx_runtime_.jsx("u", {
      children: "FREE"
    }), " Limited Edition VoT NFT!\xA0", /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: "info-icon",
      id: "info-icon",
      children: /*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: "/faq#8",
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: /*#__PURE__*/jsx_runtime_.jsx("i", {
            className: "material-icons info-icon",
            children: "info_outline"
          })
        })
      })
    })]
  });
  return /*#__PURE__*/jsx_runtime_.jsx("header", {
    className: "site-header",
    id: "site-header",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "navbar-container black",
      id: "header-container",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        className: "navbar-brand container",
        href: "/",
        id: "header-link-container",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "header-img-container",
          id: "header-img-container",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: path === "/" ? "header-img animate__animated animate__fadeInDown vot-txt-header" : "vot-txt-header header-img",
            children: (0,getWindow/* useWindowSize */.iP)().width > 880 ? /*#__PURE__*/jsx_runtime_.jsx(SvgContainer/* default */.Z, {
              layout: "responsive",
              src: images_header,
              id: "header-img",
              draggable: "false",
              description: "Village of Thousands Logo"
            }) : /*#__PURE__*/jsx_runtime_.jsx(ImageContainer/* default */.Z, {
              layout: "responsive",
              src: header,
              id: "header-img",
              draggable: "false",
              description: "Village of Thousands Logo"
            })
          })
        })
      }), userData.walletAddress ? /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {}) : /*#__PURE__*/jsx_runtime_.jsx("div", {
        id: "notification-bar",
        children: /*#__PURE__*/jsx_runtime_.jsx(components_NotificationBar, {
          text: notification,
          link: notificationLink
        })
      })]
    })
  });
};

/* harmony default export */ const components_Header = (Header);
;// CONCATENATED MODULE: ./components/Footer.js






const Footer = () => {
  const row1 = [{
    link: "/",
    name: "HOME"
  }, {
    link: "/shop",
    name: "SHOP"
  }, {
    link: "/faq#1",
    name: "ABOUT"
  }, {
    link: "/cart",
    name: "CART"
  }];
  const row2 = [{
    link: "/faq",
    name: "FAQ"
  }, {
    link: "/news",
    name: "NEWS"
  }, {
    link: "/faq#10",
    name: "CONTACT"
  }];

  const spacer = /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [" \u2003", "//", "\u2003"]
  });

  const copyright = /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: "Copyright \xA9 2022 // Village of Thousands"
  });

  const RowOne = () => {
    return row1.map((row, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: row.link,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "footer-link",
            children: row.name
          })
        })
      }), index !== row1.length - 1 ? spacer : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {})]
    }, index));
  };

  const RowTwo = () => {
    return row2.map((row, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_link["default"], {
        href: row.link,
        children: /*#__PURE__*/jsx_runtime_.jsx("a", {
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "footer-link",
            children: row.name
          })
        })
      }), index !== row2.length - 1 ? spacer : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {})]
    }, index));
  };

  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "footer animate__animated animate__fadeIn",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "page-footer",
      id: "online",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "footer-container container-fluid center disable-highlight",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx(RowOne, {})
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx(RowTwo, {})
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "copyright container center",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "copyright-text",
          children: copyright
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "gravydidit highlight-selection gravy-font container center",
          children: /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "highlight-selection-light cursor-help",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "highlight-selection-light cursor-help madewithlove",
              href: "https://www.instagram.com/gravydesignco/",
              rel: "noreferrer",
              target: "_blank",
              children: "\xA0MADE WITH LOVE BY GR\xC4VY DESIGN CO."
            })
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("br", {})]
    })
  });
};

/* harmony default export */ const components_Footer = (Footer);
;// CONCATENATED MODULE: ./components/ScrollToTop.js



const ScrollToTop = () => {
  const router = (0,router_.useRouter)();
  const {
    pathname
  } = router.pathname;
  (0,external_react_.useEffect)(() => {
    const checkId = window.location.hash ? window.location.hash.substring(1) : "";
    const qId = Number(checkId - 1);
    const rootEl = document.getElementById('layout');
    const scrollEl = document.getElementById('scrollToEl-' + qId);

    const scrollPosition = () => {
      scrollEl ? scrollEl.scrollIntoView({
        behavior: "smooth",
        block: "start"
      }) : rootEl.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    };

    setTimeout(() => {
      scrollPosition();
    }, 350);
  }, [pathname]);
  return null;
};

/* harmony default export */ const components_ScrollToTop = (ScrollToTop);
;// CONCATENATED MODULE: ./components/NavDesktop.js







const NavDesktop = () => {
  const account = Auth.loggedIn() ? "/account" : "/login";
  const navlinks = [{
    name: "account",
    ref: "person",
    link: account
  }, {
    name: "products",
    ref: "remove_red_eye",
    link: "/shop"
  }, {
    name: "faq",
    ref: "all_inclusive",
    link: "/faq"
  }, {
    name: "cart",
    ref: "shopping_cart",
    link: "/cart"
  }];

  const fingerprint = /*#__PURE__*/_jsx(Icon, {
    className: "avatar",
    children: "fingerprint"
  });

  return /*#__PURE__*/_jsxs("div", {
    className: "nav-desktop",
    children: [/*#__PURE__*/_jsx("button", {
      className: "nav-fab btn-floating btn-large",
      children: fingerprint
    }), /*#__PURE__*/_jsx("ul", {
      className: "row nav-links",
      children: navlinks.map((item, index) => /*#__PURE__*/_jsx("li", {
        className: "col s3 nav-link",
        children: /*#__PURE__*/_jsx(Link, {
          href: item.link,
          children: /*#__PURE__*/_jsx("a", {
            children: /*#__PURE__*/_jsx("button", {
              color: "inherit",
              className: "btn-floating btn-floating navigation-link nav-" + item.name,
              children: /*#__PURE__*/_jsx(Icon, {
                className: "material-Icons nav-icon",
                children: item.ref
              })
            })
          })
        })
      }, index))
    })]
  });
};

/* harmony default export */ const components_NavDesktop = ((/* unused pure expression or super */ null && (NavDesktop)));
;// CONCATENATED MODULE: ./templates/DefaultLayout.js



 // import NavMobile from './NavMobile';
// import NavDesktop from './NavDesktop';








function DefaultLayout({
  children
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(UserDataProvider, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "animate__animated animate__fadeIn",
      id: "layout",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)((head_default()), {
        children: [/*#__PURE__*/jsx_runtime_.jsx("meta", {
          charset: "utf-8"
        }), /*#__PURE__*/jsx_runtime_.jsx("title", {
          children: "Village of Thousands"
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "viewport",
          content: "width=device-width, initial-scale=1.0"
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "theme-color",
          content: "#000000"
        }), /*#__PURE__*/jsx_runtime_.jsx("meta", {
          name: "description",
          content: "Village of Thousands is an apparel company based out of Houston, TX to promote wellness driven by an environmentally conscious lifestyle."
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(components_ScrollToTop, {}), /*#__PURE__*/jsx_runtime_.jsx(components_Header, {}), /*#__PURE__*/jsx_runtime_.jsx(components_TopNav, {}), /*#__PURE__*/jsx_runtime_.jsx("div", {
        id: "content",
        className: "main-content",
        children: children
      }), /*#__PURE__*/jsx_runtime_.jsx(components_Footer, {})]
    })
  });
}

/***/ }),

/***/ 9512:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "pH": () => (/* binding */ loginUser),
/* harmony export */   "r4": () => (/* binding */ createUser),
/* harmony export */   "fp": () => (/* binding */ getSingleUser),
/* harmony export */   "Nq": () => (/* binding */ updateUser)
/* harmony export */ });
/* unused harmony export createProduct */
const createProduct = productData => {
  return fetch('/api/products', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(productData)
  });
};
const loginUser = userData => {
  return fetch('/api/users/login', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(userData)
  });
};
const createUser = userData => {
  return fetch('/api/users/', {
    method: "POST",
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(userData)
  });
};
const getSingleUser = token => {
  return fetch('/api/users/single', {
    headers: {
      'Content-Type': 'application/json',
      authorization: `Bearer ${token}`
    }
  });
};
const updateUser = (userData, token) => {
  return fetch('/api/users', {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      authorization: `Bearer ${token}`
    },
    body: JSON.stringify(userData)
  });
};

/***/ }),

/***/ 7701:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5567);
/* harmony import */ var jwt_decode__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(jwt_decode__WEBPACK_IMPORTED_MODULE_0__);
// use this to decode a token and get the user's information out of it

const ISSERVER = true; // create a new class to instantiate for a user

class AuthService {
  // get user data
  getProfile() {
    return jwt_decode__WEBPACK_IMPORTED_MODULE_0___default()(this.getToken());
  } // check if user's logged in


  loggedIn() {
    // Checks if there is a saved token and it's still valid
    const token = this.getToken();
    return !!token && !this.isTokenExpired(token); // handwaiving here
  } // check if token is expired


  isTokenExpired(token) {
    try {
      const decoded = jwt_decode__WEBPACK_IMPORTED_MODULE_0___default()(token);

      if (decoded.exp < Date.now() / 1000) {
        return true;
      } else return false;
    } catch (err) {
      return false;
    }
  }

  getToken() {
    // Retrieves the user token from localStorage
    if (!ISSERVER) {
      return localStorage.getItem('id_token');
    }

    ;
  }

  login(idToken) {
    // Saves user token to localStorage
    if (!ISSERVER) {
      localStorage.setItem('id_token', idToken);
    }

    ; // window.location.assign('/');
  }

  logout() {
    // Clear user token and profile data from localStorage
    if (!ISSERVER) {
      localStorage.removeItem('id_token');
    }

    ; // this will reload the page and reset the state of the application

    window.location.assign('/');
  }

}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (new AuthService());

/***/ }),

/***/ 2315:
/***/ ((module) => {

module.exports = JSON.parse('{"u2":"Village of Thousands","Cw":1,"rm":"Spring 2022"}');

/***/ })

};
;