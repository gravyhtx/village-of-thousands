"use strict";
exports.id = 874;
exports.ids = [874];
exports.modules = {

/***/ 5874:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_SocialCircles)
});

// EXTERNAL MODULE: ./components/SvgContainer.js
var SvgContainer = __webpack_require__(2874);
;// CONCATENATED MODULE: ./public/images/icons/github_social-circles.svg
/* harmony default export */ const github_social_circles = ({"src":"/_next/static/media/github_social-circles.e6dd0ec7.svg","height":198,"width":200});
;// CONCATENATED MODULE: ./public/images/icons/instagram_social-circles.svg
/* harmony default export */ const instagram_social_circles = ({"src":"/_next/static/media/instagram_social-circles.6f732c8e.svg","height":200,"width":200});
;// CONCATENATED MODULE: ./public/images/icons/twitter_social-circles.svg
/* harmony default export */ const twitter_social_circles = ({"src":"/_next/static/media/twitter_social-circles.af80f6b0.svg","height":200,"width":200});
;// CONCATENATED MODULE: ./public/images/icons/discord_social-circles.svg
/* harmony default export */ const discord_social_circles = ({"src":"/_next/static/media/discord_social-circles.00a7b9a5.svg","height":200,"width":200});
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: ./components/SocialCircles.js







const SocialCircles = ({
  socialContainer,
  iClass,
  width,
  icon1,
  icon2,
  icon3,
  icon4,
  icon1link,
  icon2link,
  icon3link,
  icon4link,
  icon1alt,
  icon2alt,
  icon3alt,
  icon4alt
}) => {
  iClass = iClass ? " " + iClass : " svg-color-light";
  socialContainer = socialContainer ? " " + socialContainer : "";
  width = width ? width : "";
  icon1 = icon1 ? icon1 : instagram_social_circles;
  icon2 = icon2 ? icon2 : twitter_social_circles;
  icon3 = icon3 ? icon3 : discord_social_circles;
  icon4 = icon4 ? icon4 : github_social_circles;
  icon1link = icon1link ? icon1link : "https://instagram.com/VillageOfThousands/";
  icon2link = icon2link ? icon2link : "https://twitter.com/VoThousands/";
  icon3link = icon3link ? icon3link : "https://discord.gg/EmCMFcJXbZ";
  icon4link = icon4link ? icon4link : "https://github.com/gravyhtx/village-of-thousands";
  icon1alt = icon1alt ? icon1alt : "Village of Thousands // Instagram";
  icon2alt = icon2alt ? icon2alt : "Village of Thousands // Twitter";
  icon3alt = icon3alt ? icon3alt : "Village of Thousands // Discord";
  icon4alt = icon4alt ? icon4alt : "Village of Thousands // Github";
  const icons = [{
    src: icon1,
    link: icon1link,
    alt: icon1alt
  }, {
    src: icon2,
    link: icon2link,
    alt: icon2alt
  }, {
    src: icon3,
    link: icon3link,
    alt: icon3alt
  }, {
    src: icon4,
    link: icon4link,
    alt: icon4alt
  }];
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "social-circles icon-container row",
    children: icons.map((icon, i) => /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "col s3",
      children: /*#__PURE__*/jsx_runtime_.jsx(SvgContainer/* default */.Z, {
        layout: "responsive",
        classes: "social-icon link" + iClass,
        width: width,
        description: icon.alt,
        link: icon.link,
        color: "white",
        src: icon.src
      })
    }, i))
  });
};

/* harmony default export */ const components_SocialCircles = (SocialCircles);

/***/ })

};
;