"use strict";
exports.id = 766;
exports.ids = [766];
exports.modules = {

/***/ 7766:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);



const TextContainer = ({
  containerClasses,
  containerId,
  header,
  headerClasses,
  headerId,
  text,
  textId,
  textClasses,
  border,
  fnClick,
  fnChange,
  fnBlur
}) => {
  let cClass = containerClasses ? " " + containerClasses : "";
  let cId = containerId || 'text-container';
  let hClass = headerClasses ? " " + headerClasses : "";
  let tClass = textClasses ? " " + textClasses : "";

  const handleClick = () => fnClick();

  const handleChange = () => fnChange();

  const handleBlur = () => fnBlur();

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
    onClick: fnClick ? handleClick : null,
    onChange: fnChange ? handleChange : null,
    onBlur: fnBlur ? handleBlur : null,
    className: border ? "text-container borders" + cClass : "text-container" + cClass,
    id: cId,
    children: [header ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
      className: "text-container_header" + hClass,
      id: headerId ? headerId : "text-container-header",
      children: header
    }) : "", text ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
      className: "text-container_text" + tClass,
      id: textId ? textId : "text-container-text",
      children: text
    }) : ""]
  });
}; ////////////////////////////////
//-- TEXT CONTAINER CLASSES --//
////////////////////////////////
// CONTAINER
//    Background: no-bkg, dark, light, dark-gradient
//    Box: padding, margin, no-margin/padding
// BORDERS
//    FX: thick, dark, shadow, glow
//    reverse
// HEADER:
//    dark, light, big, small, thick, thin, glow
// TEXT:
//    dark, light, dark-gradient


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TextContainer);

/***/ })

};
;