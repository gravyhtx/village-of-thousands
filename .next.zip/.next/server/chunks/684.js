exports.id = 684;
exports.ids = [684];
exports.modules = {

/***/ 2843:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mongoose = __webpack_require__(1185);

const {
  Schema,
  model
} = mongoose;
mongoose.Promise = global.Promise;
const orderSchema = new Schema({
  purchaseDate: {
    type: Date,
    default: Date.now
  },
  products: [{
    type: Schema.Types.ObjectId,
    ref: 'Product'
  }]
}); // const Order = model('Order', orderSchema);

module.exports = mongoose.models.Order || model('Order', orderSchema);
;

/***/ }),

/***/ 199:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mongoose = __webpack_require__(1185);

const {
  Schema,
  model
} = mongoose;
mongoose.Promise = global.Promise;

const bcrypt = __webpack_require__(7096);

const Order = __webpack_require__(2843);

const userSchema = new Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    match: [/.+@.+\..+/, 'Must use a valid email address']
  },
  password: {
    type: String,
    required: true
  },
  seedHex: {
    type: String,
    required: false
  },
  first_name: {
    type: String,
    required: false,
    default: ""
  },
  last_name: {
    type: String,
    required: false,
    default: ""
  },
  phone: {
    type: String,
    required: false
  },
  addressOne: {
    type: String,
    required: false
  },
  addressTwo: {
    type: String,
    required: false
  },
  city: {
    type: String,
    required: false
  },
  state: {
    type: String,
    required: false
  },
  zip: {
    type: String,
    required: false
  },
  walletAddress: {
    type: String,
    required: false,
    default: ""
  },
  walletBalance: {
    type: Number,
    required: false,
    default: 0
  },
  completeRegistration: {
    type: Boolean,
    default: true
  },
  blockie: {
    type: String,
    required: false,
    default: ""
  },
  colorScheme: [String],
  orders: [Order.schema]
}, {
  toJSON: {
    virtuals: true
  }
}); // userSchema.pre('save', async function (next) {
//   if(this.isNew || this.isModified('password')) {
//     const saltRounds = 10;
//     this.password = await bcrypt.hash(this.password, saltRounds);
//   }
// });

userSchema.methods.isCorrectPassword = async function (password) {
  return bcrypt.compare(password, this.password);
}; // const User = model('User', userSchema);


module.exports = mongoose.models.User || model('User', userSchema);

/***/ }),

/***/ 2039:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1185);
/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);

const connection = {};

async function dbConnect() {
  if (connection.isConnected) {
    return;
  }

  const db = await mongoose__WEBPACK_IMPORTED_MODULE_0___default().connect(process.env.MONGODB_URI);
  connection.isConnected = db.connections[0].readyState; // console.log(connection)
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (dbConnect);

/***/ })

};
;