exports.id = 900;
exports.ids = [900];
exports.modules = {

/***/ 4900:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

const mongoose = __webpack_require__(1185);

const {
  Schema,
  model
} = mongoose;
mongoose.Promise = global.Promise;

const bcrypt = __webpack_require__(7096);

const pendingUserSchema = new Schema({
  email: {
    type: String,
    required: true,
    unique: true,
    match: [/.+@.+\..+/, 'Must use a valid email address']
  },
  password: {
    type: String,
    required: true
  },
  seedHex: {
    type: String,
    required: false
  },
  addressOne: {
    type: String,
    required: false
  },
  addressTwo: {
    type: String,
    required: false
  },
  city: {
    type: String,
    required: false
  },
  state: {
    type: String,
    required: false
  },
  zip: {
    type: String,
    required: false
  }
}, {
  toJSON: {
    virtuals: true
  }
});
pendingUserSchema.pre('save', async function (next) {
  if (this.isNew || this.isModified('password')) {
    const saltRounds = 10;
    this.password = await bcrypt.hash(this.password, saltRounds);
  }
});

pendingUserSchema.methods.isCorrectPassword = async function (password) {
  return bcrypt.compare(password, this.password);
};

module.exports = mongoose.models.PendingUser || model('PendingUser', pendingUserSchema);

/***/ })

};
;